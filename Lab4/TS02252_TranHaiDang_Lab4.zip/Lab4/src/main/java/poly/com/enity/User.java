package poly.com.enity;

public class User {
	String account;
	String password;
	boolean gender;
	boolean married;
	String country;
	String[] hobbies;
	String note;
	
	public User() {
		// TODO Auto-generated constructor stub
	}
	
	public User(String account, String password, boolean gender, boolean married, String country, String[] hobbies,
			String note) {
		super();
		this.account = account;
		this.password = password;
		this.gender = gender;
		this.married = married;
		this.country = country;
		this.hobbies = hobbies;
		this.note = note;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public boolean isGender() {
		return gender;
	}
	public void setGender(boolean gender) {
		this.gender = gender;
	}
	public boolean isMarried() {
		return married;
	}
	public void setMarried(boolean married) {
		this.married = married;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String[] getHobbies() {
		return hobbies;
	}
	public void setHobbies(String[] hobbies) {
		this.hobbies = hobbies;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	
}
